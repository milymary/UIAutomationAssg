package runner;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.junit.AfterClass;
import org.junit.runner.RunWith;

import com.cucumber.listener.Reporter;

import cucumber.api.junit.*;
import cucumber.api.*;

@RunWith(Cucumber.class)

@CucumberOptions(
		features = "C:\\mily.mary\\Selenium_ Env\\Eclipse\\changableworkspace_temp\\UIAutomationAsgnmt\\src\\test\\java\\features\\chromeUIAutomation.feature",
		glue = { "stepDefinitions" },
		format = { "pretty", "html:test-output","junit:junit_xml/cucumber.xml" , "json:json_report/cucumber.json"}, 
		tags= { "@chromeUIAutomation" },
		plugin = {"com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/report.html" },
		dryRun =false, 
		monochrome = true
		
		
		//use iframe id  to continue program
		// credo sir:
		
		//testng based java file + in testng xml, just ad parallel tags, and add new tags from suit , clases, class ,
		//then , point, @before, @after, - to browser invoke and close
		//@main method area - point to runner file of cucumber
		
		
)

public class chromerunner {
	@AfterClass
	public static void writeExtentReport() {
		Reporter.loadXMLConfig("configs/extent-config.xml");
	}
}