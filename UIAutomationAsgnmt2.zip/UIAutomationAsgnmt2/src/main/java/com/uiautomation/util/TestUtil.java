package com.uiautomation.util;

public class TestUtil {

	public static long Page_load_timeout = 20;
	public static long IMPLICITWait_value = 20;
	public static long ExplicitWaitTimeOut_pageload = 40;

}
