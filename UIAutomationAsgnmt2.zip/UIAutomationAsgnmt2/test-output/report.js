$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/mily.mary/Selenium_ Env/Eclipse/changableworkspace_temp/UIAutomationAsgnmt/src/test/java/features/chromeUIAutomation.feature");
formatter.feature({
  "line": 1,
  "name": "User Registration and Add item to Cart with validations using Chrome browser",
  "description": "",
  "id": "user-registration-and-add-item-to-cart-with-validations-using-chrome-browser",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 6,
  "name": "User Registration and Adds item to Cart",
  "description": "",
  "id": "user-registration-and-add-item-to-cart-with-validations-using-chrome-browser;user-registration-and-adds-item-to-cart",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 5,
      "name": "@chromeUIAutomation"
    }
  ]
});
formatter.step({
  "line": 7,
  "name": "User is on Homepage",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "User navigates to SignIn Page",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "User registers with valid emailID post validation for incorrect emailID",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "User enters form details for registration",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "User navigates to MegaMenu Dresses",
  "keyword": "Then "
});
formatter.step({
  "line": 12,
  "name": "Selects Summer Dresses SubMenu",
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "Verify if grid view is selected",
  "keyword": "And "
});
formatter.step({
  "line": 14,
  "name": "User sorts items by price",
  "keyword": "Then "
});
formatter.step({
  "line": 15,
  "name": "validate if product grid is arranged properly",
  "keyword": "And "
});
formatter.step({
  "line": 16,
  "name": "User selects a product",
  "keyword": "Then "
});
formatter.step({
  "line": 17,
  "name": "User changes colour of product",
  "keyword": "And "
});
formatter.step({
  "line": 18,
  "name": "Add product to cart and checkout",
  "keyword": "Then "
});
formatter.step({
  "line": 19,
  "name": "Validate Cart Summary details for selected product details",
  "keyword": "And "
});
formatter.match({
  "location": "HomePageStepDef.homePageValidation()"
});
formatter.result({
  "duration": 20452167619,
  "error_message": "org.openqa.selenium.NoSuchWindowException: no such window: target window already closed\nfrom unknown error: web view not found\n  (Session info: chrome\u003d72.0.3626.96)\n  (Driver info: chromedriver\u003d2.38.552522 (437e6fbedfa8762dec75e2c5b3ddb86763dc9dcb),platform\u003dWindows NT 10.0.17134 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.5.3\u0027, revision: \u0027a88d25fe6b\u0027, time: \u00272017-08-29T12:42:44.417Z\u0027\nSystem info: host: \u0027LAPTOP-ISSEPS94\u0027, ip: \u0027172.20.10.2\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00279.0.1\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities [{mobileEmulationEnabled\u003dfalse, hasTouchScreen\u003dfalse, platform\u003dXP, acceptSslCerts\u003dfalse, acceptInsecureCerts\u003dfalse, webStorageEnabled\u003dtrue, browserName\u003dchrome, takesScreenshot\u003dtrue, javascriptEnabled\u003dtrue, platformName\u003dXP, setWindowRect\u003dtrue, unexpectedAlertBehaviour\u003d, applicationCacheEnabled\u003dfalse, rotatable\u003dfalse, networkConnectionEnabled\u003dfalse, chrome\u003d{chromedriverVersion\u003d2.38.552522 (437e6fbedfa8762dec75e2c5b3ddb86763dc9dcb), userDataDir\u003dC:\\Users\\BENSEB~1\\AppData\\Local\\Temp\\scoped_dir18180_24826}, takesHeapSnapshot\u003dtrue, pageLoadStrategy\u003dnormal, unhandledPromptBehavior\u003d, databaseEnabled\u003dfalse, handlesAlerts\u003dtrue, version\u003d72.0.3626.96, browserConnectionEnabled\u003dfalse, nativeEvents\u003dtrue, locationContextEnabled\u003dtrue, cssSelectorsEnabled\u003dtrue}]\nSession ID: 8d4d1c2bd1104c669926138270c92336\r\n\tat java.base/jdk.internal.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat java.base/jdk.internal.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.base/jdk.internal.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.base/java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:215)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:167)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:82)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:45)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:164)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:82)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:646)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:703)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteWebDriverOptions.deleteAllCookies(RemoteWebDriver.java:785)\r\n\tat com.uiautomation.base.TestBase.initialization(TestBase.java:65)\r\n\tat stepDefinitions.HomePageStepDef.homePageValidation(HomePageStepDef.java:26)\r\n\tat ✽.Given User is on Homepage(C:/mily.mary/Selenium_ Env/Eclipse/changableworkspace_temp/UIAutomationAsgnmt/src/test/java/features/chromeUIAutomation.feature:7)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "HomePageStepDef.clickSignInLink()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "SignInPageStepDef.registerEmailID()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "UserAccRegistrationStepDef.userRegistrationWithValidations()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "MyAccPageStepDef.userNavToMegaMenu_Dresses()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "MyAccPageStepDef.selectsSummerDressesMenu()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "SummDressPageStepDef.verifyGridVew()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "SummDressPageStepDef.sortByPrice_highestFirst()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "SummDressPageStepDef.validateGridPostSort()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "SummDressPageStepDef.user_selects_a_product()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "AddToCartPageStepDef.changeProductColour()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "AddToCartPageStepDef.checkoutProduct()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "CartSummaryPageStepDef.validateCartSummary()"
});
formatter.result({
  "status": "skipped"
});
});